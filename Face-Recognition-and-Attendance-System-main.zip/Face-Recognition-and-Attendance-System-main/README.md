# Face-Recognition-and-Attendance-System

This project has sucessfully used python libraries to create a face recognition and attendence system.

face recognition library is used to recognize faces. This library uses a neural network model to get get face encodings of a person and then tries to match them with known faces and thus classify a person.
The hosting part of this project is done on another repository [Live Attendence View](https://github.com/yash-explorer/LiveAttandanceView.git)


[Click here to see the frontend of site](https://drab-dog-sock.cyclic.app/)


[Demo video](https://github.com/yash-explorer/Face-Recognition-and-Attendance-System/assets/76256893/5fa69bbc-164d-4d8f-830f-6fc9c03c6c83)









Limitations:


1> The subjected person must be close to the camera for recognition.


2> Lighting in the environment plays an important role in recognition.


3> Accuracy of the algorithm can be increased to get more accurate results.


4>digital images are also marked present.
